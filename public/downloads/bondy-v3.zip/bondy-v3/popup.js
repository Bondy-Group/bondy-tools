// popup.js - Bondy Sourcing Assistant
// NO inline script — required by Chrome MV3 Content Security Policy

(function () {
  var keyIn   = document.getElementById('key-in');
  var saveBtn = document.getElementById('save-btn');
  var clearBtn= document.getElementById('clear-btn');
  var status  = document.getElementById('status');

  function show(msg, cls) {
    status.textContent = msg;
    status.className = 'status ' + (cls || 'muted');
  }

  // Read directly from chrome.storage (no service worker needed)
  chrome.storage.local.get(['apiKey', 'airtableApiKey'], function (r) {
    var k = r.apiKey || r.airtableApiKey || null;
    if (k) {
      keyIn.value = k;
      show('✓ API Key configurada (' + k.substring(0, 6) + '…)', 'ok');
    } else {
      show('Sin API Key. Ingresala y guardá.', 'muted');
    }
  });

  // Save directly to chrome.storage
  saveBtn.addEventListener('click', function () {
    var k = keyIn.value.trim();
    if (!k) { show('Ingresá la API Key primero.', 'err'); return; }

    show('Guardando…', 'info');
    saveBtn.disabled = true;

    chrome.storage.local.set({ apiKey: k, airtableApiKey: k }, function () {
      saveBtn.disabled = false;

      if (chrome.runtime.lastError) {
        show('Error: ' + chrome.runtime.lastError.message, 'err');
        return;
      }

      // Verify write by reading back
      chrome.storage.local.get(['apiKey'], function (r2) {
        if (r2.apiKey === k) {
          show('✓ Guardada: ' + k.substring(0, 6) + '…', 'ok');
          saveBtn.textContent = '✓ OK';
          setTimeout(function () { saveBtn.textContent = 'Guardar'; }, 2500);
        } else {
          show('Error de verificación. Valor leído: ' + JSON.stringify(r2), 'err');
        }
      });
    });
  });

  // Clear positions cache
  clearBtn.addEventListener('click', function () {
    chrome.storage.local.remove(['positions', 'bondy_positions', 'bondy_collaborators'], function () {
      show('✓ Caché limpiado', 'ok');
      setTimeout(function () { show('Listo.', 'muted'); }, 2000);
    });
  });

})();
