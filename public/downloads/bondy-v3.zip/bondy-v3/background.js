// background.js - Bondy Sourcing Assistant v2.0
// ─── Config ────────────────────────────────────────────────────────────────
const BASE_GENERAL_ID   = 'appZ2uavuwQLI2foP';
const CANDIDATOS_TABLE  = 'tblUrmhgpg33qw9in';
const CRM_BASE_ID       = 'appx2N660HZRJhWN5';
const OPORTUNIDADES_TBL = 'tblyhB7L0k0S2UOx0';

const BASE_URL     = `https://api.airtable.com/v0/${BASE_GENERAL_ID}/${CANDIDATOS_TABLE}`;
const SUPABASE_FN  = 'https://tchppyxhapxtjemxrbqm.supabase.co/functions/v1/sourcing-save';
const BONDY_KEY    = 'bondy-sourcing-2024';
const CRM_URL      = `https://api.airtable.com/v0/${CRM_BASE_ID}/${OPORTUNIDADES_TBL}`;

// Field IDs — Base General
const F = {
  NAME:        'fldRmKi9xWHEY6j46',
  LASTNAME:    'fldgNnUIVnPhIDW6j',
  FULLNAME:    'fldNsMBt9IU5p2LUf',
  EMAIL:       'fldrNKdJMuTYZyc4W',
  LINKEDIN:    'fldhs28ujRrHfDcCk',
  GITHUB:      'fldm8ey3GriOT8JZz',
  CITY:        'fldrdm7orGb27UOuv',
  COUNTRY:     'fld1qRiBPV8LouaHJ',
  SENIORITY:   'fld7gpje9o34Udm7p',
  PROFILE:     'fld1l56bUrKkBoy9B',
  SKILLS2:     'fldJyjMfDTderh80i',
  ENGLISH:     'fldRON9VP3DcF3jbp',
  STATUS:      'fldYH6JxkBcqj9BR7',
  LAST_CNT:    'fld1BbcKbB8otHkdg',
  SOURCER:     'fldKX3vjKNkxnfGg9',
  TAS:         'fldpnPgKUpJsdRFnf',
  POSITION:    'fldtdLwwgEUBAJb35',
  ACCOUNT:     'fldhBhh2ZGQp7KBU2',
  FUENTES:     'fldavfw4LkP6LrvED',
  SALARY:      'fldKmz3vPAkP2YS62',
  NOTES:       'fldcPaVQmeFmqPK5B',
  CELLPHONE:   'fldmiwyzyNBFN57BA',
  WORKMODEL:   'fldn73Suxshj2fZZo',
  REJECTION:   'fldFmD85L4KPOQvyN',
};

// Team (hardcoded — no API call needed)
const TEAM = [
  { id: 'usrr2h7fD1Cn3PIig', name: 'Mara Schmitman' },
  { id: 'usrKPGBXOWF7V4Mjj', name: 'Laura Schmitman' },
  { id: 'usrqmOCcyJt9zV2NK', name: 'Lucía Palomeque' },
  { id: 'usr84XQDJWpxM8oH7', name: 'Ximena Ubellart' },
  { id: 'usrnPVNd4wiPbHKkb', name: 'Rodrigo Lopez Paiva' },
  { id: 'usrtpesOEubRRZlUV', name: 'Facundo Sepulveda' },
];

// ─── Storage helpers ────────────────────────────────────────────────────────
const CACHE_TTL = 24 * 60 * 60 * 1000;

async function getCached(key) {
  return new Promise(resolve => {
    chrome.storage.local.get([key], r => {
      const e = r[key];
      resolve(e && Date.now() - e.ts < CACHE_TTL ? e.data : null);
    });
  });
}
async function setCache(key, data) {
  return new Promise(resolve => {
    chrome.storage.local.set({ [key]: { data, ts: Date.now() } }, resolve);
  });
}
async function getKey() {
  return new Promise(resolve => {
    // Read both keys for backwards compatibility with older extension versions
    chrome.storage.local.get(['apiKey', 'airtableApiKey'], r => {
      resolve(r.apiKey || r.airtableApiKey || null);
    });
  });
}

// ─── Fetch helper ────────────────────────────────────────────────────────────
async function apiFetch(url, opts = {}, timeout = 12000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  try {
    const r = await fetch(url, { ...opts, signal: ctrl.signal });
    clearTimeout(t);
    return r;
  } catch (e) {
    clearTimeout(t);
    throw e;
  }
}

// ─── Search candidates ───────────────────────────────────────────────────────
// Returns ALL records matching this person (one per process/búsqueda)
async function searchCandidates(query, type) {
  const key = await getKey();
  if (!key) return { error: 'NO_API_KEY' };

  let formula = '';
  if (type === 'linkedin') {
    // Extract handle from URL for flexible matching
    const m = query.replace(/[?#].*$/, '').replace(/\/$/, '').match(/linkedin\.com\/in\/([^/?#]+)/i);
    const handle = m ? m[1].toLowerCase() : query.toLowerCase();
    formula = `FIND("${handle}", LOWER({linkedin}))`;
  } else if (type === 'github') {
    const m = query.replace(/[?#].*$/, '').replace(/\/$/, '').match(/github\.com\/([^/?#]+)/i);
    const handle = m ? m[1].toLowerCase() : query.toLowerCase();
    formula = `FIND("${handle}", LOWER({Repositorio / Portfolio}))`;
  } else if (type === 'name') {
    const parts = query.trim().split(/\s+/);
    if (parts.length >= 2) {
      formula = `AND(SEARCH(LOWER("${parts[0]}"),LOWER({Name})),SEARCH(LOWER("${parts[parts.length-1]}"),LOWER({Lastname})))`;
    } else {
      formula = `OR(SEARCH(LOWER("${query}"),LOWER({Name})),SEARCH(LOWER("${query}"),LOWER({Lastname})))`;
    }
  }

  if (!formula) return { records: [] };

  try {
    const url = new URL(BASE_URL);
    url.searchParams.set('filterByFormula', formula);
    url.searchParams.set('maxRecords', '50');
    url.searchParams.set('sort[0][field]', 'Last contact date');
    url.searchParams.set('sort[0][direction]', 'desc');
    // Fields we need for the history view
    const fields = [
      'Name & Lastname','Name','Lastname','Status','linkedin',
      'Last contact date','Talent Sourcer','Talent Acquisition Specialist',
      'Position name','Account','Seniority','Profile','Email',
      'Rejection reason','Fuentes'
    ];
    fields.forEach(f => url.searchParams.append('fields[]', f));

    const res = await apiFetch(url.toString(), {
      headers: { 'Authorization': `Bearer ${key}` }
    });
    if (!res.ok) {
      const err = await res.json();
      return { error: err.error?.message || `HTTP ${res.status}` };
    }
    const data = await res.json();
    return { records: data.records || [] };
  } catch (e) {
    return { error: e.message };
  }
}

// ─── Create candidate ─────────────────────────────────────────────────────────
async function createCandidate(fields) {
  const key = await getKey();
  if (!key) return { error: 'NO_API_KEY' };
  try {
    // typecast: true lets Airtable accept flexible values for singleSelect/
    // multipleSelects/collaborator/linked-record fields (case-insensitive match,
    // auto-create where allowed). This makes the extension robust to small
    // drift between the extension's option lists and Airtable's choices.
    const res = await apiFetch(BASE_URL, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ fields, typecast: true })
    });
    if (!res.ok) {
      // Try to surface the useful part of Airtable's error
      let errMsg = `HTTP ${res.status}`;
      try {
        const err = await res.json();
        errMsg = err.error?.message || err.error?.type || errMsg;
      } catch {}
      return { error: errMsg };
    }
    const record = await res.json();

    // Also save to Supabase (fire-and-forget — don't block on failure)
    saveToSupabase(fields, record.id).catch(() => {});

    return { record };
  } catch (e) {
    return { error: e.message };
  }
}

// ─── Fetch active positions from CRM ──────────────────────────────────────────
async function fetchPositions() {
  const cached = await getCached('positions');
  if (cached) return { positions: cached };

  const key = await getKey();
  if (!key) return { error: 'NO_API_KEY', positions: [] };

  try {
    // Filter: Status contains "On Going" or "Potencial"
    const formula = `OR(FIND("On Going",{Status}),FIND("Potencial",{Status}))`;
    const url = new URL(CRM_URL);
    url.searchParams.set('filterByFormula', formula);
    url.searchParams.append('fields[]', 'Opportunity name');
    url.searchParams.append('fields[]', 'Status');
    url.searchParams.set('sort[0][field]', 'Opportunity name');
    url.searchParams.set('maxRecords', '200');

    const res = await apiFetch(url.toString(), {
      headers: { 'Authorization': `Bearer ${key}` }
    });

    let records = [];
    if (res.ok) {
      const data = await res.json();
      records = data.records || [];
    } else {
      // Fallback: all without filter
      const url2 = new URL(CRM_URL);
      url2.searchParams.append('fields[]', 'Opportunity name');
      url2.searchParams.set('maxRecords', '200');
      const res2 = await apiFetch(url2.toString(), {
        headers: { 'Authorization': `Bearer ${key}` }
      });
      if (res2.ok) {
        const data2 = await res2.json();
        records = data2.records || [];
      }
    }

    const positions = records
      .map(r => ({
        id: r.id,
        name: (r.fields?.['Opportunity name'] || '').replace(/[\u{1F300}-\u{1FFFF}]/gu, '').trim()
      }))
      .filter(p => p.name);

    await setCache('positions', positions);
    return { positions };
  } catch (e) {
    return { error: e.message, positions: [] };
  }
}

// ─── Save to Supabase ─────────────────────────────────────────────────────────
async function saveToSupabase(fields, airtableRecordId) {
  try {
    // Map Airtable field names to Supabase payload
    const payload = {
      full_name:      fields['Name'] && fields['Lastname']
                        ? `${fields['Name']} ${fields['Lastname']}`.trim()
                        : fields['Name'] || fields['Lastname'] || '',
      email:          fields['Email'] || null,
      linkedin_url:   fields['linkedin'] || null,
      github_url:     fields['Repositorio / Portfolio'] || null,
      location:       fields['City'] && fields['Country']
                        ? `${fields['City']}, ${fields['Country']}`
                        : fields['City'] || fields['Country'] || null,
      seniority:      fields['Seniority'] || null,
      profile:        Array.isArray(fields['Profile']) ? fields['Profile'].join(', ') : (fields['Profile'] || null),
      skills:         fields['Skills'] ? fields['Skills'].split(',').map(s => s.trim()).filter(Boolean) : null,
      airtable_id:    airtableRecordId || null,
      // Process fields
      status:         fields['Status'] || 'sourced',
      position_name:  Array.isArray(fields['Position name'])
                        ? (fields['Position name'][0]?.name || null)
                        : null,
      client_name:    Array.isArray(fields['Account'])
                        ? (fields['Account'][0]?.name || null)
                        : null,
      sourcer_name:   fields['Talent Sourcer']?.name || null,
      recruiter_name: fields['Talent Acquisition Specialist']?.name || null,
      source:         fields['Fuentes'] || 'LinkedIn',
    };

    if (!payload.full_name) return { error: 'No name to save' };

    const res = await apiFetch(SUPABASE_FN, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Bondy-Key': BONDY_KEY,
      },
      body: JSON.stringify(payload),
    }, 10000);

    const data = await res.json();
    if (!res.ok) return { error: data.error || `HTTP ${res.status}` };
    return { ok: true, candidate_id: data.candidate_id, pipeline_id: data.pipeline_id };
  } catch (e) {
    return { error: e.message };
  }
}

// ─── Message handler ─────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  const { action, payload } = msg;

  if (action === 'SEARCH') {
    searchCandidates(payload.query, payload.type).then(reply);
    return true;
  }
  if (action === 'CREATE') {
    createCandidate(payload.fields).then(reply);
    return true;
  }
  if (action === 'GET_POSITIONS') {
    fetchPositions().then(reply);
    return true;
  }
  if (action === 'GET_TEAM') {
    reply({ team: TEAM });
    return false;
  }
  if (action === 'SAVE_KEY') {
    // Save under both keys for compatibility
    chrome.storage.local.set({ apiKey: payload.key, airtableApiKey: payload.key }, () => reply({ ok: true }));
    return true;
  }
  if (action === 'GET_KEY') {
    getKey().then(k => reply({ key: k }));
    return true;
  }
  if (action === 'CLEAR_CACHE') {
    chrome.storage.local.remove(['positions'], () => reply({ ok: true }));
    return true;
  }
});
