// content.js - Bondy Sourcing Assistant v2.0
(function () {
  'use strict';
  if (document.getElementById('bondy-root')) return;

  // ─── Platform ──────────────────────────────────────────────────────────────
  const host = location.hostname;

  function platform() {
    const path = location.pathname;
    if (host.includes('linkedin.com')) {
      if (/^\/in\/[^/]+/.test(path)) return 'linkedin';
      if (path.startsWith('/search/')) return 'linkedin-search';
      return null;
    }
    if (host.includes('juicebox.ai')) return 'juicebox';
    if (host === 'github.com') {
      const parts = path.split('/').filter(Boolean);
      const skip = ['orgs','topics','trending','explore','marketplace','settings','login','signup'];
      if (parts.length === 1 && !skip.includes(parts[0])) return 'github';
      return null;
    }
    return null;
  }

  // Computed lazily — re-evaluated on each init() call, so SPA nav works.
  let PLATFORM = platform();
  // If we're not on a valid profile page right now, don't abort: LinkedIn is a
  // SPA, the user may navigate here from /feed or /search. We install the
  // navigation watcher below and wait for a profile URL.

  // ─── Status options ────────────────────────────────────────────────────────
  const STATUSES = [
    'Sourced','Ready to be contacted by sourcer','Contacted','Contacted By Email',
    'Message',"Didn't answer",'Ghosting','Follow up','Re-engage!',
    'Interested','Bondy HR Interview','Submitted','Shortlist',
    'Client Interview','Challenge','Psicometrics','Offer','HIRED',
    'Offer rejection','Client Rejection','Candidate Rejection','Candidate withdrew',
    'TAS Rejection','TAS Rejectionw/Interview','TAS Rejection without interview',
    'Stand By','Backup','In Process','Replacement'
  ];
  const SENIORITIES = ['Junior','Semi-Senior','Senior','Lead','Principal','Staff','Manager'];
  const PROFILES = [
    'Backend Engineer','Frontend Engineer','Full Stack Engineer','DevOps Engineer',
    'Data Engineer','Data Scientist','ML Engineer','QA Engineer','Automation Engineer',
    'Mobile Developer','iOS Developer','Android Developer','React Native Developer',
    'Product Manager','Tech Lead','Software Architect','Engineering Manager',
    'Cloud Engineer','Security Engineer','Site Reliability Engineer','Platform Engineer',
    'AI Engineer','Blockchain Developer','Systems Engineer','CTO','VP Engineering',
  ];
  const ENGLISH = ['A1','A2','B1','B2','C1','C2','Native'];
  const SOURCES = ['LinkedIn','Juicebox','GitHub','Referral','Apply Now','Other'];
  const STATUS_COLORS = {
    'Sourced':            { bg:'#E8F4FD', t:'#1565C0' },
    'Ready to be contacted by sourcer': { bg:'#E8F4FD', t:'#1565C0' },
    'Contacted':          { bg:'#FFF8E1', t:'#E65100' },
    'Contacted By Email': { bg:'#FFF8E1', t:'#E65100' },
    'Message':            { bg:'#FFF8E1', t:'#E65100' },
    "Didn't answer":      { bg:'#F3E5F5', t:'#6A1B9A' },
    'Ghosting':           { bg:'#F3E5F5', t:'#6A1B9A' },
    'Follow up':          { bg:'#FFF8E1', t:'#F57F17' },
    'Interested':         { bg:'#E8F5E9', t:'#2E7D32' },
    'Bondy HR Interview': { bg:'#E8F5E9', t:'#2E7D32' },
    'Submitted':          { bg:'#E3F2FD', t:'#1565C0' },
    'Shortlist':          { bg:'#E3F2FD', t:'#1565C0' },
    'Client Interview':   { bg:'#E0F7FA', t:'#00695C' },
    'Challenge':          { bg:'#E0F7FA', t:'#00695C' },
    'Offer':              { bg:'#F1F8E9', t:'#33691E' },
    'HIRED':              { bg:'#2E7D32', t:'#FFFFFF' },
    'Offer rejection':    { bg:'#FFEBEE', t:'#B71C1C' },
    'Client Rejection':   { bg:'#FFEBEE', t:'#B71C1C' },
    'Candidate Rejection':{ bg:'#FFEBEE', t:'#B71C1C' },
    'Candidate withdrew': { bg:'#FFEBEE', t:'#B71C1C' },
    'TAS Rejection':      { bg:'#FFEBEE', t:'#B71C1C' },
    'TAS Rejectionw/Interview': { bg:'#FFEBEE', t:'#B71C1C' },
    'TAS Rejection without interview': { bg:'#FFEBEE', t:'#B71C1C' },
    'Stand By':           { bg:'#ECEFF1', t:'#455A64' },
    'Backup':             { bg:'#ECEFF1', t:'#455A64' },
    'In Process':         { bg:'#E8F5E9', t:'#2E7D32' },
  };

  function statusColor(s) {
    return STATUS_COLORS[s] || { bg: '#F5F5F5', t: '#424242' };
  }

  // ─── Profile extraction ────────────────────────────────────────────────────
  function extractLinkedIn() {
    const d = {
      platform: 'linkedin',
      linkedinUrl: location.href.replace(/[?#].*$/, '').replace(/\/$/, ''),
      name: '', firstName: '', lastName: '', headline: '', location: ''
    };
    // Try multiple name selectors in order
    const nameSelectors = [
      'h1.text-heading-xlarge',
      'h1[class*="text-heading"]',
      'h1[class*="heading-xlarge"]',
      '.pv-text-details__left-panel h1',
      '.ph5 h1',
      'main section h1',
      'h1',
    ];
    for (const sel of nameSelectors) {
      const el = document.querySelector(sel);
      if (el && el.innerText && el.innerText.trim().length > 1) {
        d.name = el.innerText.trim();
        break;
      }
    }
    // og:title fallback: "John Doe - Title | LinkedIn"
    if (!d.name) {
      const og = document.querySelector('meta[property="og:title"]');
      if (og) {
        const raw = (og.getAttribute('content') || '').split(' - ')[0].split(' | ')[0].trim();
        if (raw && !raw.toLowerCase().includes('linkedin')) d.name = raw;
      }
    }
    if (d.name) {
      const p = d.name.trim().split(/\s+/);
      d.firstName = p[0] || '';
      d.lastName = p.slice(1).join(' ') || '';
    }
    const hlSels = ['.text-body-medium.break-words','[class*="headline"]','.pv-text-details__left-panel .text-body-medium'];
    for (const sel of hlSels) {
      const el = document.querySelector(sel);
      if (el && el.innerText && el.innerText.trim() !== d.name) { d.headline = el.innerText.trim(); break; }
    }
    const locSels = ['.text-body-small.inline.t-black--light.break-words','[data-field="location"] span'];
    for (const sel of locSels) {
      const el = document.querySelector(sel);
      if (el && el.innerText.trim()) { d.location = el.innerText.trim(); break; }
    }
    return d;
  }

  function extractGitHub() {
    const d = {
      platform: 'github',
      githubUrl: location.href.replace(/[?#].*$/, '').replace(/\/$/, ''),
      name: '', firstName: '', lastName: '', location: '', email: ''
    };
    const username = location.pathname.split('/').filter(Boolean)[0] || '';
    const nameEl = document.querySelector('[itemprop="name"], .p-name, .vcard-fullname');
    d.name = nameEl ? nameEl.innerText.trim() : username;
    if (d.name) {
      const p = d.name.trim().split(/\s+/);
      d.firstName = p[0] || '';
      d.lastName = p.slice(1).join(' ') || '';
    }
    const locEl = document.querySelector('[itemprop="homeLocation"], .p-label');
    if (locEl) d.location = locEl.innerText.trim();
    const emailEl = document.querySelector('[itemprop="email"], a[href^="mailto:"]');
    if (emailEl) d.email = (emailEl.href || '').replace('mailto:', '') || emailEl.innerText.trim();
    return d;
  }

  function extractJuicebox() {
    const d = { platform: 'juicebox', name: '', firstName: '', lastName: '', linkedinUrl: '' };
    const sels = ['[data-testid="candidate-name"]', '.candidate-name', 'h1', 'h2'];
    for (const sel of sels) {
      const el = document.querySelector(sel);
      if (el && el.innerText && el.innerText.trim().length > 1 && el.innerText.trim().length < 60) {
        d.name = el.innerText.trim();
        break;
      }
    }
    const liLink = document.querySelector('a[href*="linkedin.com/in/"]');
    if (liLink) d.linkedinUrl = liLink.href.replace(/[?#].*$/, '').replace(/\/$/, '');
    if (d.name) {
      const p = d.name.trim().split(/\s+/);
      d.firstName = p[0] || '';
      d.lastName = p.slice(1).join(' ') || '';
    }
    return d;
  }

  function extract() {
    if (PLATFORM === 'linkedin') return extractLinkedIn();
    if (PLATFORM === 'github') return extractGitHub();
    if (PLATFORM === 'juicebox') return extractJuicebox();
    return {};
  }

  // ─── Helpers ───────────────────────────────────────────────────────────────
  function esc(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function norm(v) {
    if (!v) return '';
    if (typeof v === 'string') return v;
    if (Array.isArray(v)) return v.map(x => x.name || x).join(', ');
    return v.name || v.email || String(v);
  }
  function fmtDate(d) {
    if (!d) return '—';
    try { return new Date(d).toLocaleDateString('es-AR', { day:'2-digit', month:'2-digit', year:'numeric' }); }
    catch { return d; }
  }
  function daysAgo(d) {
    if (!d) return null;
    return Math.floor((Date.now() - new Date(d).getTime()) / 86400000);
  }
  function msg(action, payload) {
    return new Promise(resolve => {
      try {
        chrome.runtime.sendMessage({ action, payload }, r => {
          if (chrome.runtime.lastError) resolve({ error: chrome.runtime.lastError.message });
          else resolve(r || {});
        });
      } catch (e) { resolve({ error: e.message }); }
    });
  }

  // ─── State ─────────────────────────────────────────────────────────────────
  let isOpen = false;
  let profileData = null;
  let positions = [];
  let team = [];

  // ─── Panel HTML ────────────────────────────────────────────────────────────
  function buildPanel() {
    const root = document.createElement('div');
    root.id = 'bondy-root';
    root.innerHTML = `
      <div id="bondy-btn" title="Bondy Sourcing">
        <svg width="22" height="22" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="4" y="5" width="14" height="12" rx="2.5" fill="#1A1A1A"/>
          <rect x="22" y="5" width="14" height="12" rx="2.5" fill="#1A1A1A" opacity="0.25"/>
          <rect x="4" y="22" width="14" height="12" rx="2.5" fill="#1A1A1A" opacity="0.55"/>
          <rect x="22" y="22" width="14" height="12" rx="2.5" fill="#4A8C40"/>
        </svg>
      </div>
      <div id="bondy-panel">
        <div id="bondy-header">
          <div class="bondy-logo-wrap">
            <svg width="22" height="22" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="4" y="5" width="14" height="12" rx="2.5" fill="#1A1A1A"/>
              <rect x="22" y="5" width="14" height="12" rx="2.5" fill="#1A1A1A" opacity="0.18"/>
              <rect x="4" y="22" width="14" height="12" rx="2.5" fill="#1A1A1A" opacity="0.42"/>
              <rect x="22" y="22" width="14" height="12" rx="2.5" fill="#4A8C40"/>
            </svg>
            <span class="bondy-wordmark">BONDY</span>
          </div>
          <button id="bondy-x">✕</button>
        </div>
        <div id="bondy-body">
          <div id="bondy-spinner" class="bondy-spinner-wrap">
            <div class="bondy-spin"></div>
            <span>Verificando en Airtable…</span>
          </div>
          <div id="bondy-content" style="display:none"></div>
        </div>
      </div>
    `;
    document.body.appendChild(root);
  }

  function setPanel(open) {
    isOpen = open;
    const panel = document.getElementById('bondy-panel');
    const btn = document.getElementById('bondy-btn');
    if (!panel) return;
    panel.style.display = open ? 'flex' : 'none';
    btn.style.display = open ? 'none' : 'flex';
    if (open && !document.getElementById('bondy-content').innerHTML) {
      runSearch();
    }
  }

  // ─── Render history view ───────────────────────────────────────────────────
  function renderHistory(records) {
    const content = document.getElementById('bondy-content');
    if (!content) return;

    const seen = new Set();
    const unique = records.filter(r => seen.has(r.id) ? false : (seen.add(r.id), true));

    const latest = unique[0];
    const lf = latest?.fields || {};
    const name = norm(lf['Name & Lastname']) || `${norm(lf['Name'])} ${norm(lf['Lastname'])}`.trim() || '—';
    const latestStatus = norm(lf['Status']);
    const sc = statusColor(latestStatus);
    const lastDate = lf['Last contact date'];
    const days = daysAgo(lastDate);
    const isRecent = days !== null && days < 30;

    const rows = unique.map((r, i) => {
      const f = r.fields || {};
      const status = norm(f['Status']);
      const date = f['Last contact date'];
      const sourcer = norm(f['Talent Sourcer']);
      const tas = norm(f['Talent Acquisition Specialist']);
      const position = norm(f['Position name']);
      const account = norm(f['Account']);
      const rejection = norm(f['Rejection reason']);
      const c = statusColor(status);
      return `
        <div class="bh-row${i===0?' bh-latest':''}">
          <div class="bh-left">
            <div class="bh-dot" style="background:${c.t}"></div>
            ${i < unique.length-1 ? '<div class="bh-line"></div>' : ''}
          </div>
          <div class="bh-card">
            <div class="bh-card-top">
              <span class="bh-badge" style="background:${c.bg};color:${c.t}">${esc(status||'—')}</span>
              <span class="bh-date">${fmtDate(date)}</span>
            </div>
            ${position ? `<div class="bh-field"><span class="bh-lbl">🔍 Búsqueda</span><span class="bh-val">${esc(position)}</span></div>` : ''}
            ${account  ? `<div class="bh-field"><span class="bh-lbl">🏢 Cliente</span><span class="bh-val">${esc(account)}</span></div>` : ''}
            ${sourcer  ? `<div class="bh-field"><span class="bh-lbl">👤 Sourcer</span><span class="bh-val">${esc(sourcer)}</span></div>` : ''}
            ${tas      ? `<div class="bh-field"><span class="bh-lbl">🎯 Recruiter</span><span class="bh-val">${esc(tas)}</span></div>` : ''}
            ${rejection? `<div class="bh-field"><span class="bh-lbl">❌ Motivo</span><span class="bh-val">${esc(rejection)}</span></div>` : ''}
            <a href="https://airtable.com/appZ2uavuwQLI2foP/tblUrmhgpg33qw9in/${r.id}" target="_blank" class="bh-link">Ver en Airtable →</a>
          </div>
        </div>`;
    }).join('');

    content.innerHTML = `
      <div class="bc-head">
        <div class="bc-name">${esc(name)}</div>
        <div class="bc-badges">
          <span class="bh-badge" style="background:${sc.bg};color:${sc.t}">${esc(latestStatus||'—')}</span>
          ${isRecent ? `<span class="bc-warn">⚠️ ${days}d</span>` : ''}
        </div>
        <div class="bc-count">${unique.length} proceso${unique.length!==1?'s':''} registrado${unique.length!==1?'s':''}</div>
      </div>
      <div class="bc-section-title">Historial de procesos</div>
      <div class="bh-list">${rows}</div>
      <button class="bondy-add-btn" id="bondy-add-another">+ Agregar a nueva búsqueda</button>
    `;

    document.getElementById('bondy-add-another')?.addEventListener('click', () => {
      renderAddForm(profileData, true);
    });
  }

  // ─── Render add form ────────────────────────────────────────────────────────
  function renderAddForm(pd, isAdding = false) {
    const content = document.getElementById('bondy-content');
    if (!content) return;

    const defaultSource = pd?.platform === 'linkedin' ? 'LinkedIn'
      : pd?.platform === 'github' ? 'GitHub'
      : pd?.platform === 'juicebox' ? 'Juicebox' : '';

    const posOptions = positions.map(p =>
      `<option value="${esc(p.id)}">${esc(p.name)}</option>`
    ).join('');

    const teamOptions = team.map(t =>
      `<option value="${esc(t.id)}">${esc(t.name)}</option>`
    ).join('');

    const title = isAdding ? 'Agregar a nueva búsqueda' : 'Nuevo candidato';
    const detectedName = pd?.name || '';
    const detectedUrl = pd?.linkedinUrl || pd?.githubUrl || '';

    content.innerHTML = `
      <div class="bf-head">${esc(title)}</div>
      ${isAdding ? `<div class="bf-subtitle">${esc(detectedName)}</div>` : ''}
      ${!isAdding ? `
        <div class="bf-detected">
          ${detectedName ? `<span class="bf-det-val">👤 ${esc(detectedName)}</span>` : '<span class="bf-det-warn">⚠️ Nombre no detectado</span>'}
          ${detectedUrl ? `<span class="bf-det-val">🔗 ${esc(detectedUrl.replace('https://www.linkedin.com/in/','').replace('https://github.com/','').replace(/\/$/,''))}</span>` : ''}
          <button class="bf-retry" id="bondy-retry">↻ Volver a buscar</button>
        </div>` : ''}
      <div class="bf-form" id="bondy-form">
        ${!isAdding ? `
        <div class="bf-row2">
          <input class="bf-in" name="firstName" placeholder="Nombre *" value="${esc(pd?.firstName||'')}" required />
          <input class="bf-in" name="lastName" placeholder="Apellido *" value="${esc(pd?.lastName||'')}" required />
        </div>
        <input class="bf-in" name="email" type="email" placeholder="Email" />
        <input class="bf-in" name="linkedin" placeholder="LinkedIn URL" value="${esc(pd?.linkedinUrl||'')}" />
        <input class="bf-in" name="github" placeholder="GitHub URL" value="${esc(pd?.githubUrl||'')}" />
        <input class="bf-in" name="location" placeholder="Ciudad, País" value="${esc(pd?.location||'')}" />
        <div class="bf-row2">
          <select class="bf-sel" name="seniority">
            <option value="">Seniority</option>
            ${SENIORITIES.map(s=>`<option>${esc(s)}</option>`).join('')}
          </select>
          <select class="bf-sel" name="english">
            <option value="">Inglés</option>
            ${ENGLISH.map(e=>`<option>${esc(e)}</option>`).join('')}
          </select>
        </div>
        <select class="bf-sel" name="profile">
          <option value="">Perfil</option>
          ${PROFILES.map(p=>`<option>${esc(p)}</option>`).join('')}
        </select>
        <select class="bf-sel" name="source">
          <option value="${esc(defaultSource)}">${esc(defaultSource||'Fuente')}</option>
          ${SOURCES.filter(s=>s!==defaultSource).map(s=>`<option>${esc(s)}</option>`).join('')}
        </select>
        ` : ''}

        <div class="bf-divider">Proceso</div>
        <select class="bf-sel" name="status">
          <option value="Sourced">Sourced (default)</option>
          ${STATUSES.filter(s=>s!=='Sourced').map(s=>`<option>${esc(s)}</option>`).join('')}
        </select>
        <select class="bf-sel" name="position">
          <option value="">Búsqueda / Posición</option>
          ${posOptions}
        </select>
        <select class="bf-sel" name="sourcer">
          <option value="">Sourcer</option>
          ${teamOptions}
        </select>
        <select class="bf-sel" name="tas">
          <option value="">Recruiter (TAS)</option>
          ${teamOptions}
        </select>

        <button class="bf-submit" id="bondy-submit">Guardar en Airtable</button>
        <div class="bf-status" id="bondy-form-status"></div>
        ${isAdding ? `<button class="bf-back" id="bondy-back">← Volver al historial</button>` : ''}
      </div>
    `;

    document.getElementById('bondy-submit')?.addEventListener('click', submitForm.bind(null, isAdding, pd));
    document.getElementById('bondy-back')?.addEventListener('click', () => { runSearch(); });
    document.getElementById('bondy-retry')?.addEventListener('click', () => { runSearch(); });
  }

  // ─── Submit form ────────────────────────────────────────────────────────────
  async function submitForm(isAdding, pd) {
    const form = document.getElementById('bondy-form');
    const statusEl = document.getElementById('bondy-form-status');
    const submitBtn = document.getElementById('bondy-submit');
    if (!form) return;

    const get = name => form.querySelector(`[name="${name}"]`)?.value?.trim() || '';

    const fields = {};

    if (!isAdding) {
      const firstName = get('firstName');
      const lastName  = get('lastName');
      if (!firstName) { if (statusEl) statusEl.textContent = 'El nombre es requerido'; return; }
      fields['Name']     = firstName;
      fields['Lastname'] = lastName;

      const email   = get('email');
      const linkedin= get('linkedin') || pd?.linkedinUrl || '';
      const github  = get('github')   || pd?.githubUrl   || '';
      const location= get('location') || pd?.location    || '';
      const seniority = get('seniority');
      const english   = get('english');
      const profile   = get('profile');
      const source    = get('source');

      if (email)    fields['Email'] = email;
      if (linkedin) fields['linkedin'] = linkedin;
      if (github)   fields['Repositorio / Portfolio'] = github;
      if (location) {
        const parts = location.split(',').map(s=>s.trim());
        if (parts[0])                fields['City'] = parts[0];
        if (parts[parts.length - 1]) fields['Country'] = parts[parts.length - 1];
      }
      if (seniority) fields['Seniority'] = seniority;
      if (english)   fields['English Level'] = english;
      if (profile)   fields['Profile'] = [profile];
      if (source)    fields['Fuentes'] = source;
    } else {
      // When adding to new búsqueda, copy key identifiers from profileData
      if (pd?.name) {
        const parts = pd.name.trim().split(/\s+/);
        fields['Name']     = parts[0] || '';
        fields['Lastname'] = parts.slice(1).join(' ') || '';
      }
      if (pd?.linkedinUrl) fields['linkedin'] = pd.linkedinUrl;
      if (pd?.githubUrl)   fields['Repositorio / Portfolio'] = pd.githubUrl;
    }

    // Process fields (always)
    const status  = get('status');
    const posId   = get('position');
    const sourcer = get('sourcer');
    const tas     = get('tas');

    if (status)  fields['Status'] = status;
    // Position name is a multipleRecordLinks field → array of record ID strings.
    // (NOT [{id: ...}] — that format is only for write-via-field-IDs or collaborators.)
    if (posId)   fields['Position name'] = [posId];
    // Talent Sourcer / TAS are singleCollaborator fields → {id: userId}.
    if (sourcer) fields['Talent Sourcer'] = { id: sourcer };
    if (tas)     fields['Talent Acquisition Specialist'] = { id: tas };

    // Stamp Last contact date to today when we save a new process row
    fields['Last contact date'] = new Date().toISOString().slice(0, 10);

    // Disable button
    submitBtn.disabled = true;
    submitBtn.textContent = 'Guardando…';
    if (statusEl) statusEl.textContent = '';

    const result = await msg('CREATE', { fields });

    submitBtn.disabled = false;

    if (result?.record) {
      submitBtn.textContent = '✓ Guardado';
      submitBtn.style.background = '#2E7D32';
      if (statusEl) {
        statusEl.textContent = 'Guardado correctamente';
        statusEl.style.color = '#2E7D32';
      }
    } else {
      submitBtn.textContent = 'Guardar en Airtable';
      if (statusEl) {
        statusEl.textContent = `Error: ${result?.error || 'Intento fallido'}`;
        statusEl.style.color = '#B71C1C';
      }
    }
  }

  // ─── Run search ────────────────────────────────────────────────────────────
  async function runSearch() {
    const spinner = document.getElementById('bondy-spinner');
    const content = document.getElementById('bondy-content');
    if (!spinner || !content) return;

    spinner.style.display = 'flex';
    content.style.display = 'none';
    content.innerHTML = '';

    profileData = extract();

    // Search in parallel with positions/team fetch
    const searchPromise = (async () => {
      let result = null;

      // 1. Try LinkedIn URL (most reliable)
      if (profileData.linkedinUrl) {
        result = await msg('SEARCH', { query: profileData.linkedinUrl, type: 'linkedin' });
      }

      // 2. Try GitHub URL
      if (!result?.records?.length && profileData.githubUrl) {
        result = await msg('SEARCH', { query: profileData.githubUrl, type: 'github' });
      }

      // 3. Try full name
      if (!result?.records?.length && profileData.name && profileData.name.trim().length > 2) {
        result = await msg('SEARCH', { query: profileData.name, type: 'name' });
      }

      // 4. Try just first + last name separately if full name search fails
      if (!result?.records?.length && profileData.firstName && profileData.lastName) {
        result = await msg('SEARCH', { query: profileData.firstName + ' ' + profileData.lastName, type: 'name' });
      }

      return result || { records: [] };
    })();

    const dropPromise = (async () => {
      if (!positions.length) {
        const pr = await msg('GET_POSITIONS');
        if (pr?.positions) positions = pr.positions;
      }
      if (!team.length) {
        const tr = await msg('GET_TEAM');
        if (tr?.team) team = tr.team;
      }
    })();

    const [searchResult] = await Promise.all([searchPromise, dropPromise]);

    spinner.style.display = 'none';
    content.style.display = 'block';

    if (searchResult?.error === 'NO_API_KEY') {
      content.innerHTML = `
        <div class="bondy-no-key">
          <div style="font-size:28px">🔑</div>
          <strong>Falta la API Key</strong>
          <p>Hacé clic en el ícono <b>B</b> en la barra de Chrome y configurá tu API key de Airtable.</p>
        </div>`;
      return;
    }

    const records = searchResult?.records || [];
    if (records.length > 0) {
      renderHistory(records);
    } else {
      renderAddForm(profileData, false);
    }
  }

  // ─── Init ──────────────────────────────────────────────────────────────────
  function init() {
    // Always re-read the platform — URL may have changed since module load
    PLATFORM = platform();
    if (!PLATFORM || PLATFORM === 'linkedin-search') return;
    if (document.getElementById('bondy-root')) return;
    buildPanel();

    document.getElementById('bondy-btn')?.addEventListener('click', () => setPanel(true));
    document.getElementById('bondy-x')?.addEventListener('click', () => setPanel(false));

    // Auto-open on profile pages
    setTimeout(() => setPanel(true), 1500);
  }

  function tryInit() {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init, { once: true });
    } else {
      // Give the page a moment to render — especially on SPA navigations
      setTimeout(init, 400);
    }
  }

  tryInit();

  // ─── SPA navigation watcher ────────────────────────────────────────────────
  // LinkedIn / Juicebox / GitHub are SPAs; the content-script only runs once
  // per page load. We watch for URL changes and re-init so the panel appears
  // whether the user landed directly on a profile or navigated in from feed/
  // search/home.
  let lastUrl = location.href;
  let navTimer = null;

  function onNavigate() {
    const cur = location.href;
    if (cur === lastUrl) return;
    lastUrl = cur;

    if (navTimer) clearTimeout(navTimer);

    // Tear down the old panel immediately so stale data never shows
    const existing = document.getElementById('bondy-root');
    if (existing) existing.remove();
    isOpen = false;
    profileData = null;

    // Wait for the new page DOM to settle (LinkedIn is slow to render
    // profile DOM after URL swap — 2s is the minimum that's worked reliably)
    navTimer = setTimeout(() => {
      navTimer = null;
      init();
    }, 2000);
  }

  // Patch history API to catch pushState/replaceState (SPA navigations)
  const _push = history.pushState;
  const _replace = history.replaceState;
  history.pushState = function () {
    const r = _push.apply(this, arguments);
    onNavigate();
    return r;
  };
  history.replaceState = function () {
    const r = _replace.apply(this, arguments);
    onNavigate();
    return r;
  };
  window.addEventListener('popstate', onNavigate);

  // Fallback: also watch the body for child-list mutations. Most SPA
  // frameworks use pushState, but LinkedIn sometimes changes URL via other
  // means. We only react when location.href actually differs.
  new MutationObserver(onNavigate).observe(document.body, { childList: true });

})();
